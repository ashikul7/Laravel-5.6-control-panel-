;

<?php $__env->startSection("mainContent"); ?>;
	<h1> Add Category</h1>
	<hr>
	<?php echo e(Session::get("msg")); ?>


	<?php echo Form::open(['url' => '/save-category', 'method'=>'POST', 'class'=>'form-horizontal']); ?>

	  <div class="form-group">
	    <label class="control-label col-sm-2" for="categoryName">Category Name:</label>
	    <div class="col-sm-10">
	      <input type="text" class="form-control" id="categoryName" placeholder="Category Name" name="categoryName">

	    </div>
	  </div>

	  <div class="form-group">
	    <label class="control-label col-sm-2" for="categoryDescription">Category Description:</label>
	    <div class="col-sm-10"> 
	      <textarea class="form-control" id="categoryDescription" placeholder="Enter Description" name="categoryDescription"></textarea>

	    </div>
	  </div>

	  <div class="form-group"> 
	    	<label class="control-label col-sm-2" for="pubStatusDes">Publication Status Description</label>
		    <div class="col-sm-10"> 
		      <select class="form-control" id="publicationStatus" name="pub">
		      	<option>Select Publication Status</option>
		      	<option value="1">Published</option>
		      	<option value="0">Unpublished</option>
		      </select>
		    </div>
	  </div>

	  <div class="form-group"> 
	    <div class="col-sm-offset-2 col-sm-10">
	      <button type="submit" class="btn btn-default btn-success">Submit</button>
	    </div>
	  </div>
	<?php echo Form::close(); ?>

	
	<?php echo $__env->make("admin.error.errors", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>;
	      

<?php $__env->stopSection(); ?>;
<?php echo $__env->make("admin.master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>