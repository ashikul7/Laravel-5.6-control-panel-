;

<?php $__env->startSection("mainContent"); ?>
	<h1>Manage Product</h1>
	<hr>
	<?php echo e(Session::get("msg")); ?>


	 <table class="table">
	    <thead>
	      <tr>
	        <th>Sl</th>
	        <th>Product Name</th>
	        <th>Category Name</th>
	        <th>Price</th>
	        <th>Quantity</th>
	        <th>Picture</th>
	        <th>Publication Status</th>
	        <th>Action</th>
	      </tr>
	    </thead>
	    <tbody>
	    	<?php
	    		$i = 0;
	    	?>
	    	<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	      <tr>
	        <td><?php echo e(++$i); ?></td>
	        <td><?php echo e($product->productName); ?></td>
	        <td><?php echo e($product->categoryName); ?></td>
	        <td><?php echo e($product->productPrice); ?></td>
	        <td><?php echo e($product->productQuantity); ?></td>
	        <td><img src="<?php echo e(asset($product->productPicture)); ?>" width="100"/><?php echo e($product->productPicture); ?></td>
	        <td><?php echo e($product->productStatus == 1? "Published" : "Unpublished"); ?></td>
	        <td><a href="<?php echo e(url('/view-product/'.$product->id)); ?>">View</a> | <a href ="<?php echo e(url('/edit-product/' .$product->id)); ?>">Edit</a> | <a href="<?php echo e(url('/delete-product/' .$product->id)); ?>" onclick="return confirm('Are you sure to delete the product')">Delete</a></td>
	      </tr>
	      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	    </tbody>
	  </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("admin.master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>