<?php $__env->startSection("mainContent"); ?>
	<h1>Manage Categories</h1>
	<hr>
	<?php echo e(Session::get("msg")); ?>

	 <table class="table">
	    <thead>
	      <tr>
	        <th>Sl</th>
	        <th>Category Name</th>
	        <th>Category Description</th>
	        <th>Publication Status</th>
	        <th>Action</th>
	      </tr>
	    </thead>
	    <tbody>
	    	<?php
	    		$i = 0;
	    	?>
	    	<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	      <tr>
	        <td><?php echo e(++$i); ?></td>
	        <td><?php echo e($category->categoryName); ?></td>
	        <td><?php echo e($category->categoryDescription); ?></td>
	        <td><?php echo e($category->publicationStatus ==1? "Published" : "Unpublished"); ?></td>
	        <td><a href="<?php echo e(url('/edit-category/' .$category->id)); ?>">Edit</a> | <a href="<?php echo e(url('delete-category/' .$category->id)); ?>">Delete</a></td>
	      </tr>
	      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	    </tbody>
	  </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("admin.master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>