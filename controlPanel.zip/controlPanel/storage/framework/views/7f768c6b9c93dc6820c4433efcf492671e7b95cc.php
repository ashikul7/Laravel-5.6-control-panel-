<?php $__env->startSection("mainContent"); ?>
	<h1>Product Details</h1>
	<img src ="<?php echo e(asset($product->productPicture)); ?>" width="300"/>

	<table>
		<tr>
			<td>Product Name</td><td>:</td><td class="text-primary"><?php echo e($product->productName); ?></td>
		</tr>
		<tr>
			<td>Category Name</td><td>:</td><td><?php echo e($product->categoryName); ?></td>
		</tr>
		<tr>
			<td>Product Price</td><td>:</td><td><?php echo e($product->productPrice); ?></td>
		</tr>
		<tr>
			<td>Product Quantity</td><td>:</td><td><?php echo e($product->productQuantity); ?></td>
		</tr>
		<tr>
			<td>Product Description</td><td>:</td><td><?php echo e($product->productDescription); ?></td>
		</tr>
		<tr>
			<td>Publication Status</td><td>:</td><td><?php echo e($product->productStatus ==1? "Published" : "Unpublished"); ?></td>
		</tr>
	</table>
	<a href ="<?php echo e(url('/manage-product')); ?>">Back to Manage Product</a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("admin.master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>