<?php $__env->startSection("mainContent"); ?>
	<h1>Edit Category</h1>
	<hr>

	<?php echo Form::open(['url' => '/update-category', 'method'=>'POST', 'class'=>'form-horizontal', "name"=>"editForm"]); ?>

	  <div class="form-group">
	    <label for="category">Category Name:</label>
	    <input type="text" class="form-control" id="categoryName" name="categoryName" value="<?php echo e($categoryById->categoryName); ?>">
	  </div>
	  <div class="form-group">
	    <label for="pwd">Category Description:</label>
	    <textarea name="categoryDescription" class="form-control" id="categoryDescription">
	    	<?php echo e($categoryById->categoryDescription); ?>

	    </textarea>
	  </div>
	  <div class="form-group">
	    <label for="publicationStatus">Publication Status:</label>
	    <select class ="form-control" name="publicationStatus">
	    	<?php echo e($categoryById->publicationStatus); ?>

	    	<option>Select Publication Status</option>
	    	<option value="1">Published</option>
	    	<option value="0">Unpublished</option>
	    </select>
	  </div>
	  <input type="hidden" name="categoryId" value="<?php echo e($categoryById->id); ?>">

	  <button type="submit" class="btn btn-default btn-success">Submit</button>
	<?php echo Form::close(); ?>

	<script>
		document.forms["editForm"].elements["publicationStatus"].value=<?php echo e($categoryById->publicationStatus); ?>

	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("admin.master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>